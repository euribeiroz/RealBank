module bank {
	exports bankAcc;
}